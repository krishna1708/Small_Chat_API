<?php

require_once __DIR__.'/IdentityKeyStore.php';
abstract class AxolotlStore extends IdentityKeyStore
{
}
